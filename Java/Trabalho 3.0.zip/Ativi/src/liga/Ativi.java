package liga;

import java.util.Scanner;

public class Ativi {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String senhaCorreta = "senha123";
        String senhaDigitada;


        while (true) {
            System.out.println("Digite a senha:");
            senhaDigitada = sc.nextLine();

            if (senhaDigitada.equals(senhaCorreta)) {
                System.out.println("SENHA CORRETA");
                break;
            } else {
                System.out.println("ERRO DE SENHA");
            }
        }

        while (true) {
            System.out.println("1-Cadastro do Cliente/2-Compra de Carro/3-Compra de Acessorio");
            int opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {
                case 1:
                    System.out.println("-----------Cadastro de Cliente-----------");
                    System.out.println("Nome do Cliente");
                    String nome = sc.nextLine();
                    System.out.println("Telefone do Cliente");
                    String tele = sc.nextLine();
                    System.out.println("Endereço do Cliente");
                    String endereco = sc.nextLine();
                    break;
                case 2:
                    System.out.println("Escolha o modelo de carro:");
                    System.out.println("1 - Sedan");
                    System.out.println("2 - Honda");
                    System.out.println("3 - Mercedes");
                    int opcaoCarro = sc.nextInt();
                    String produto = "";
                    switch (opcaoCarro) {
                        case 1:
                            produto = "Sedan";
                            break;
                        case 2:
                            produto = "Honda";
                            break;
                        case 3:
                            produto = "Mercedes";
                            break;
                        default:
                            produto = "Valor inválido";
                            break;
                    }
                    System.out.print("Digite a cor desejada para o carro: ");
                    String corCarro = sc.next();

                    System.out.println("Escolha a forma de pagamento:");
                    System.out.println("1. À vista");
                    System.out.println("2. Parcelado");
                    System.out.print("Digite o número correspondente à forma de pagamento desejada: ");
                    int opcaoPagamento = sc.nextInt();

                    String formaPagamento = "";
                    switch (opcaoPagamento) {
                        case 1:
                            formaPagamento = "À vista";
                            break;
                        case 2:
                            formaPagamento = "Parcelado";
                            break;
                        default:
                            System.out.println("Opção inválida. Escolha entre 1 ou 2.");
                            return;
                    }

                    System.out.println("\nDetalhes da compra:");
                    System.out.println("Produto escolhido: " + produto);
                    System.out.println("Cor do carro: " + corCarro);
                    System.out.println("Forma de pagamento: " + formaPagamento);
                    break;
                case 3:
                
                    System.out.print("Informe o nome do acessório: ");
                    String nomeAcessorio = sc.next();
                    System.out.print("Quantidade Desejada: ");
                    int quantidade = sc.nextInt();
                    comprarAcessorio(nomeAcessorio, quantidade, sc);
                    break;


                default:
                    System.out.println("Opção incorreta");
            }
        }
    }

	private static void comprarAcessorio(String nomeAcessorio,int quantidade,  Scanner sc) {
		// TODO Auto-generated method stub
		
	}
}

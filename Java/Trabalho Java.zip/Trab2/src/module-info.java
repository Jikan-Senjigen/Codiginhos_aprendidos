/**
 * 
 */
/**
 * 
 */
module Trab2 {
}
package entities;

public class Graduacao_nomes {

	
    private String nome;
    private String cpf;
    private String matricula;
    private String cursoGraduacao;

    
    public Graduacao_nomes(String nome, String cpf, String matricula, String cursoGraduacao) {
        this.nome = nome;
        this.cpf = cpf;
        this.matricula = matricula;
        this.cursoGraduacao = cursoGraduacao;
    }    
    public String getNome() {
        return nome;}
    public void setNome(String nome) {
        this.nome = nome;}
    public String getCpf() {
        return cpf;}
    public void setCpf(String cpf) {
        this.cpf = cpf; }
    public String getMatricula() {
        return matricula;}
    public void setMatricula(String matricula) {
        this.matricula = matricula; }
    public String getCursoGraduacao() {
        return cursoGraduacao;}
    public void setCursoGraduacao(String cursoGraduacao) {
        this.cursoGraduacao = cursoGraduacao;
    }
}

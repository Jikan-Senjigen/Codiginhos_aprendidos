package entities;
import entities.Graduacao_nomes;
import entities.PosGraduacao_nomes;
public class Teste {
		
		public static void main(String[] args) {
			Graduacao_nomes estudanteGraduacao = new Graduacao_nomes(
	                "Luis Guilherme", "12345678900", "ucb20231001", "Analise e Desenvolvimento de Sistemas");

	        
	        System.out.println("----------------Graduação----------------");
	        System.out.println("Nome: " + estudanteGraduacao.getNome());
	        System.out.println("CPF: " + estudanteGraduacao.getCpf());
	        System.out.println("Matrícula: " + estudanteGraduacao.getMatricula());
	        System.out.println("Curso de Graduação: " + estudanteGraduacao.getCursoGraduacao());

	        
	        PosGraduacao_nomes estudantePosGraduacao = new PosGraduacao_nomes(
	                "Luis Guilherme Alves De Sousa", "98765432100", "ucb20242002", "Analise e Desenvolvimento de Sistemas");

	        
	        System.out.println("\n----------------Pós-Graduação----------------");
	        System.out.println("Nome: " + estudantePosGraduacao.getNome());
	        System.out.println("CPF: " + estudantePosGraduacao.getCpf());
	        System.out.println("Matrícula: " + estudantePosGraduacao.getMatricula());
	        System.out.println("Curso de Pós-Graduação: " + estudantePosGraduacao.getCursoPosgraduacao());
	    
	

	}

}

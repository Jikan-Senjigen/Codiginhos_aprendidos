package entities;

public class PosGraduacao_nomes {
	
    private String nome;
    private String cpf;
    private String matricula;
    private String cursoPosgraduacao;

    
    public PosGraduacao_nomes(String nome, String cpf, String matricula, String cursoPosgraduacao) {
        this.nome = nome;
        this.cpf = cpf;
        this.matricula = matricula;
        this.cursoPosgraduacao = cursoPosgraduacao;
    }

    
    public String getNome() {
        return nome;}
    public void setNome(String nome) {
        this.nome = nome;}
    public String getCpf() {
        return cpf;}
    public void setCpf(String cpf) {
        this.cpf = cpf;}
    public String getMatricula() {
        return matricula;}
    public void setMatricula(String matricula) {
        this.matricula = matricula;}
    public String getCursoPosgraduacao() {
        return cursoPosgraduacao;}
    public void setCursoPosgraduacao(String cursoPosgraduacao) {
        this.cursoPosgraduacao = cursoPosgraduacao;}
}



package Aplicattion;

import java.util.Scanner;

import Entities.Estudante_Eduarda_Luis_Vitoria;
import Entities.Estudantes_Eduarda_Luis_Vitoria;
import Entities.Pessoas;



public class Programa_Eduarda_luis_Vitoria extends Pessoas {
	public Programa_Eduarda_luis_Vitoria(String nome, String cpf, String matricula) {
		super(nome, cpf, matricula);
	}


	public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
			Pessoas[] pessoas = new Pessoas[10];
			int contador = 0;

			while (true) {
				System.out.println("---------------- BEM-VINDOS(AS) AO SCHOOL FIVE ---------------- ");
			    System.out.println("1 - Cadastro Graduação");
			    System.out.println("2 - Cadastro Pós-Graduação");
			    System.out.println("3 - Sair");
			    System.out.print("Escolha uma opção:\n");
			    int opcao = scanner.nextInt();
			    scanner.nextLine(); // Limpar o buffer do scanner

			    if (opcao == 1) {
			        if (contador < 10) {
			        	System.out.println("----------- GRADUAÇÃO -----------");
			            System.out.print("Nome: ");
			            String nome = scanner.nextLine();
			            System.out.print("CPF: ");
			            String cpf = scanner.nextLine();
			            System.out.print("Matrícula: ");
			            String matricula = scanner.nextLine();
			            System.out.print("Curso de Graduação: ");
			            String cursoGraduacao = scanner.nextLine();
			            pessoas[contador] = new Estudante_Eduarda_Luis_Vitoria(nome, cpf, matricula, cursoGraduacao);
			            contador++;
			        } else {
			            System.out.println("Limite de cadastros atingido.");
			        }
			    } else if (opcao == 2) {
			        if (contador < 10) {
			        	System.out.println("----------- PÓS-GRADUAÇÃO -----------");
			            System.out.print("Nome: ");
			            String nome = scanner.nextLine();
			            System.out.print("CPF: ");
			            String cpf = scanner.nextLine();
			            System.out.print("Matrícula: ");
			            String matricula = scanner.nextLine();
			            System.out.print("Curso de Pós-Graduação: ");
			            String cursoPosgraduacao = scanner.nextLine();
			            pessoas[contador] = new Estudantes_Eduarda_Luis_Vitoria(nome, cpf, matricula, cursoPosgraduacao);
			            contador++;
			        } else {
			            System.out.println("Limite de cadastros atingido.");
			        }
			    } else if (opcao == 3) {
			        break;
			    } else {
			        System.out.println("Opção inválida. Tente novamente!");
			    }
			}

			System.out.println("REGISTROS REALIZADOS:");
			for (int i = 0; i < contador; i++) {
			    System.out.println(pessoas[i].toString());
			}
			}
        }
	}

	
    

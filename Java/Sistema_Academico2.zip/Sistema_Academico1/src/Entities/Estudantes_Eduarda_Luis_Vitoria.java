package Entities;

public class Estudantes_Eduarda_Luis_Vitoria extends Pessoas{


    private String nome;
    private String cpf;
    private String matricula;
    private String cursoPosgraduacao;

	    public Estudantes_Eduarda_Luis_Vitoria(String nome, String cpf, String matricula, String cursoPosgraduacao) {
	        super(nome, cpf, matricula);
	        this.cursoPosgraduacao = cursoPosgraduacao;
	        this.nome = nome;
	        this.cpf = cpf;
	        this.matricula = matricula;
	        this.cursoPosgraduacao = cursoPosgraduacao;
    }
	    

    
    public String getNome() {
        return nome;}
    public void setNome(String nome) {
        this.nome = nome;}
    public String getCpf() {
        return cpf;}
    public void setCpf(String cpf) {
        this.cpf = cpf;}
    public String getMatricula() {
        return matricula;}
    public void setMatricula(String matricula) {
        this.matricula = matricula;}
    public String getCursoPosgraduacao() {
        return cursoPosgraduacao;}
    public void setCursoPosgraduacao(String cursoPosgraduacao) {
        this.cursoPosgraduacao = cursoPosgraduacao;}



	@Override
	public String toString() {
		return "\n -------PÓS-GRADUAÇÃO-------\n NOME:" + nome + "\n CPF:" + cpf + "\n MATRÍCULA:" + matricula + "\n PÓS-GRADUAÇÃO:"
				+ cursoPosgraduacao + "\n";
	}
}




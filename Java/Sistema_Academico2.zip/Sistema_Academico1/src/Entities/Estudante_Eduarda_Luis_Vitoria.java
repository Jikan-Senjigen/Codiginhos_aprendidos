package Entities;

public class Estudante_Eduarda_Luis_Vitoria extends Pessoas {
	 private String nome;
	    private String cpf;
	    private String matricula;
	    private String cursoGraduacao;

	    
	    public Estudante_Eduarda_Luis_Vitoria(String nome, String cpf, String matricula, String cursoPosgraduacao) {
	        super(nome, cpf, matricula);
	        this.cursoGraduacao = cursoPosgraduacao;
	        this.nome = nome;
	        this.cpf = cpf;
	        this.matricula = matricula;
	        this.cursoGraduacao = cursoPosgraduacao;
	    }    
	    public String getNome() {
	        return nome;}
	    public void setNome(String nome) {
	        this.nome = nome;}
	    public String getCpf() {
	        return cpf;}
	    public void setCpf(String cpf) {
	        this.cpf = cpf; }
	    public String getMatricula() {
	        return matricula;}
	    public void setMatricula(String matricula) {
	        this.matricula = matricula; }
	    public String getCursoGraduacao() {
	        return cursoGraduacao;}
	    public void setCursoGraduacao(String cursoGraduacao) {
	        this.cursoGraduacao = cursoGraduacao;
	    }
		@Override
		public String toString() {
			return "\n -------GRADUAÇÃO-------\n NOME:" + nome + "\n CPF:" + cpf + "\n MATRÍCULA:" + matricula + "\n GRADUAÇÃO:"
					+ cursoGraduacao + "\n";
		}
	    

}
